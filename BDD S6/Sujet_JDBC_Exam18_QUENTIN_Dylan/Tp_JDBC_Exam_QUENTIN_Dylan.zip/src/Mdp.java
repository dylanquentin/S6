
public class Mdp {

	public static String mdp = "Lvirgin031274";
}
